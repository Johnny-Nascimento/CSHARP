﻿namespace SerenattoEnsaio.Dados;
public class DadosFormaDePagamento
{
    public static List<string> FormasDePagamento = new List<string>
    {
        "crédito", "débito", "pix","dinheiro"
    };
}
