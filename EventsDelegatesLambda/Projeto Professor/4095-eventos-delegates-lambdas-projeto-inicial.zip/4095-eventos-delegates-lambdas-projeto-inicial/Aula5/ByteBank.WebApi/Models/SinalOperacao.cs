﻿namespace ByteBank.WebApi.Models
{
    public enum SinalOperacao
    {
        Credito = 1,
        Debito = -1
    }
}